# HeroesApp

## Dev

1. Clonar el proyecto
2. Ejecutar ```npm install```
3. Levantar backend ```npm run backend```
4. Ejecutar la app ```npm start``` o bien ```ng serve -o```


