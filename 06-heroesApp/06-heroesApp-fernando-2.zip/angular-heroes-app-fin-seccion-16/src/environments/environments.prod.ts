

export const environments = {
  baseUrl: 'https://fernando-herrera.com/api'
}
